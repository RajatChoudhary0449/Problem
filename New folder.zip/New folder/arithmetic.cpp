int maximum(int A,int B)
{
	if(A>B)
	return A;
	return B;
}
