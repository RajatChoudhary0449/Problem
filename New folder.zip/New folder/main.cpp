#include<iostream>
#include "arithmetic.h"
using namespace std;
int main()
{
	int max=maximum(10,20);
	cout<<max<<endl;
}
